import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

//Aliana Squires

public class App {


    static Scanner scnr = new Scanner(System.in);
    static Random rnd = new Random();

    public static boolean validate(String userinput,ArrayList<String> allWords, ArrayList<Character>wordLetters  ){
        if((allWords.contains(userinput))){
            for(int i = 0; i < userinput.length(); i++){
            if ((wordLetters.contains(userinput.charAt(i)))){
                continue;
            } else {
                return false;
            }
        }
        }
        
        return true;
    }
    /*
     * create a meathod that counts the charactors to give it a score
     * @param is users input
     * if less than 4 letters than = 0, if 4 letters then = 1, if more, if 4 then = 1 per chanractor.
     * @return score
     */

    public static int count(String userinput, int score) {
        
        if (userinput.length() < 4) {
            score = 0;
        } else if (userinput.length() == 4) {
            score = 1;
        } else if (userinput.length() > 4) {
            score = userinput.length();
        }
        return score;

        // find a way to add the score
    }

    /*
     * mix the charactors
     * @param wordletters
     * @return wordletters shuffled
     */
    public static ArrayList<Character> mix(ArrayList<Character> wordLetters){
        Collections.shuffle(wordLetters);
        return wordLetters;
    }

    public static void list(ArrayList<String> validwords){
        if(validwords != null){
            for(int i = 0; i < validwords.size(); i++){
                System.out.println(validwords.get(i));
            }
        }
        else{
            System.out.println("Empty list");
        }
    }
    public static boolean checkvalid(String userinput, ArrayList<String> validwords){
        if(validwords != null){
            for(int i = 0; i < validwords.size(); i++){
                if(validwords.get(i).equals(userinput) ){
                    return false;
                }
                
            }
        }
        return true;
    }

    public static void main(String[] args) throws FileNotFoundException {

        String filePath = "words.txt";
        File textwords = new File(filePath);
        try (Scanner filScanner = new Scanner(textwords)) {
            ArrayList<String> allWords = new ArrayList<>();
            while (filScanner.hasNext()) {
                allWords.add(filScanner.next());
            }
            /*
             * a while loop that pritns out the charactors
             * @param is chosenword
             * @return is wordLetters
             */

             //How do I space this information out?
            String chosenword;
            ArrayList<Character> wordLetters = new ArrayList<>();
            while(true){
            int num = rnd.nextInt(allWords.size());
            chosenword = allWords.get(num);

            for(int i = 0; i < chosenword.length(); i++){
                wordLetters.add(chosenword.charAt(i));
            }
            Collections.sort(wordLetters);
            char letter_word = wordLetters.get(0);

            for(int i = 1; i < wordLetters.size(); i++){
                if(letter_word == wordLetters.get(i)){
                    wordLetters.remove(i);
                    i = i - 1;

                }else{
                    letter_word = wordLetters.get(i);
                }
            }
            if(wordLetters.size() == 7){
            break;
            }
            wordLetters.clear();
            
    }
    ArrayList<String> validwords = new ArrayList<>();
    
    for(char c : wordLetters){
        System.out.print(c + " ");
    }
    System.out.println();

    int score = 0;

    while(true){

    // TODO: in class notes
    //GOAL: validate a userword given a dictionary
    // read from words.txt 
    //words.txt contains strings
    //read in the string to an array / arraylist
    // not have entered mix,ls,or bye.
    //capture user string
    //check that the charactor length meets the minimum
    //check that it is in the words.txt
    //check if the charactors of the word are contained in the game word charactors 
    // loop through userword and check if charactor is in game word
    //if valid then score and store the word
    //if not valid score 0

    

    String userinput = scnr.nextLine();
    String mix = "mix";
    String ls = "ls";
    String bye = "bye";

    /*
     * if stament that calls in my given methods
     * @param is userinput
     * @return mix, or ls, or aword, or bye
     */
    if (userinput.equals(mix)){
            mix(wordLetters);
            for(char c : wordLetters){
        System.out.print(c + " ");
    }
    System.out.println();
    }
    else if (userinput.equals(ls)){
            list(validwords);
    }
    else if(userinput.equals(bye)){
        break;
    }

    if(validate(userinput, allWords, wordLetters) && (userinput.length() > 3)){
        if(checkvalid(userinput, validwords)){
            score += count(userinput, score);
        validwords.add(userinput);
        }
        System.out.println("Score: " + score);
        
    }
    else{
        score += count(userinput, score);
        System.out.println("Score: " + score);
    }

    

    filScanner.close();

}

        scnr.close();

    }
}
}
